<?php

//Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "pap");

// Verifica a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Processa o voto
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_artistas = intval($_POST['id_artistas']);
    $conn->query("UPDATE artistas SET votocoes = id_votacao + 1 WHERE id = $id_artistas");
    echo "<p>Voto registrado com sucesso!</p>";
}

// Busca os artistas
$result = $conn->query("SELECT * FROM artistas");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Votação de Artistas</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1200px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }

        .card {
            display: flex;
            align-items: center;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            overflow: hidden;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .card img {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 10px 0 0 10px;
        }

        .card-content {
            flex: 1;
            padding: 20px;
        }

        .card-content h3 {
            margin: 10px 0;
            color: #444;
            text-align: center;
        }

        .card-content p {
            margin: 5px 0;
            color: #666;
            font-size: 14px;
        }

        .card-action {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background-color: #f4f4f4;
            border-left: 1px solid #eee;
        }

        .card-action input[type="radio"] {
            display: none;
        }

        .card-action label {
            display: block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border-radius: 5px;
            text-align: center;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .card-action label:hover {
            background-color: #0056b3;
        }

        .button-submit {
            display: block;
            margin: 20px auto;
            padding: 10px 30px;
            font-size: 16px;
            color: #fff;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-align: center;
        }

        .button-submit:hover {
            background-color: #218838;
        }

        .centro {
            text-align: center;
        }

        .artista {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .info {
            flex: 1;
            padding: 0 20px;
        }

        .votar {
            padding: 0 20px;
        }
    </style>
    <?php 
    
    $id_local = $conn->query("SELECT * FROM locais");
    ?>
</head>
<body>
    <div class="container">
        <h1 type="center">Escolha o Artista</h1>
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="artista">
                <img src="<?= $row['imagem'] ?>" alt="Foto do <?= $row['nome'] ?>">
                <div class="info">
                    <h3><?= $row['nome'] ?></h3>
                    <p>Local de Atuação: <?= isset($row['id_local']) ? $row['id_cidade'] : 'N/A' ?></p>
                </div>
                <div class="votar">
                    <form method="POST" action="">
                        <input type="hidden" name="id_artistas" value="<?= $row['id_votacao'] ?>">
                        <button type="submit" class="btn btn-primary">Votar</button>
                    </form>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>
